from rds_connect_decorator import *

"""
@params: area (de negócio relativa ao CSV de origem recebido)
@params: df (dataframe contendo os dados do CSV)

@description: A partir dos parâmetros acima, recupera as regras/parâmetros de validação no db e as executa.
@return: dataframe original acrescido de novas colunas referentes aos status das validações realizadas.
"""
def validarDataframe(area, df):
  ## Carregando as regras do banco
  rows = getRegras(area)
  #for row in rows:
    #print('row: \n', row)
  #print(df['Status'])
  df['flag_status'] = df['Status'].apply(validarStatus)
  
  return df


"""
Recebe o status como parâmetro e o valida de acordo com as regras parametrizadas.
Caso não esteja em conformidade, retorna a string 'STATUS_INVALIDO'. Do contrário, retorna None.
O valor retornado será armazenado em uma nova coluna no dataframe original.
TODO: recuperar as regras / parâmetros de cada coluna no bd.
"""
def validarStatus(status):
  result = None

  if int(status) != 6 and int(status) != 7:
    result = 'STATUS_INVALIDO'
      
  return result  