import logging
import json
import boto3
import io
from io import StringIO
import pandas as pd
#import queue_wrapper
import uuid
from datetime import datetime
import os
from botocore.exceptions import ClientError
from dotenv import load_dotenv
import botocore 
import botocore.session 
from aws_secretsmanager_caching import SecretCache, SecretCacheConfig 
from util_validacoes import *

# load env variables
if os.path.isfile('.env.local'):
  load_dotenv('.env.local')
else:
  load_dotenv('.env')

logger = logging.getLogger(__name__)
endpoint_url = "http://localhost.localstack.cloud:4566"

if os.getenv('PYTHON_ENV') == 'dev':
  secrets_client = botocore.session.get_session().create_client('secretsmanager', endpoint_url=endpoint_url)
  s3_client = boto3.client('s3', endpoint_url=endpoint_url)
  dynamodb_client = boto3.resource('dynamodb', endpoint_url=endpoint_url)
  sqs_client = boto3.resource('sqs', endpoint_url=endpoint_url)
else:  
  secrets_client = botocore.session.get_session().create_client('secretsmanager')
  s3_client = boto3.client('s3')
  dynamodb_client = boto3.resource('dynamodb')
  sqs_client = boto3.resource('sqs')


def from_df_to_json(df):
  try: 
    jsonStr = df.to_json(orient='records')
    #print('jsonStr: \n', jsonStr)
    #time.sleep(10)
  except Exception as error:
    print('Erro ao converter o dataframe para json: ', error)  
  
  try:
    jsonObj = json.loads(jsonStr)
  except Exception as error:
    print('Erro ao converter a string json em objeto json: ', error)

  return jsonObj   


def store_message(df):
  table = dynamodb_client.Table('pricing')
  jsonObj = from_df_to_json(df)

  try:
    with table.batch_writer() as writer:
      for item in jsonObj:
        #print('item: \n', item)
        item = {
            'id': str(uuid.uuid1()),
            'row': json.dumps(item)
        }
        writer.put_item(Item=item)
  
  except Exception as error:
    print('Erro ao inserir os dados no dynamodb: ', error) 

def pack_message(msg_path, msg_body, msg_line):
  return {
      "body": msg_body,
      "attributes": {
          "path": {"StringValue": msg_path, "DataType": "String"},
          "line": {"StringValue": str(msg_line), "DataType": "String"},
      },
  }

def send_message_tosqs(df):
  jsonObj = from_df_to_json(df)
  queue = sqs_client.get_queue_by_name(QueueName='pricing')

  try:
    entries = [
      {
          "Id": str(uuid.uuid1()),
          "MessageBody": json.dumps(item),
      }
      for item in jsonObj
    ]
    response = queue.send_messages(Entries=entries)
    print('response: \n', response)
    if "Successful" in response:
      for msg_meta in response["Successful"]:
        logger.info(
            "Message sent: %s",
            msg_meta["MessageId"],
        )
    if "Failed" in response:
      for msg_meta in response["Failed"]:
        logger.warning(
            "Falha ao enviar a msg para a fila: %s", response['Failed']['Message'],
        )
  except ClientError as error:
    logger.exception("Erro ao enviar mensagens para a fila: %s", queue)
    raise error
  else:
    return response
   

def lambda_handler(event, context):
  print('Lambda started')

  try:
      
    s3_Bucket_Name = event["Records"][0]["s3"]["bucket"]["name"]
    s3_File_Name = event["Records"][0]["s3"]["object"]["key"]

    #print('s3_Bucket_Name: ', s3_Bucket_Name)
    #print('s3_File_Name: ', s3_File_Name)
    
    object = s3_client.get_object(Bucket=s3_Bucket_Name, Key=s3_File_Name)
    body = object['Body']
    csv_string = body.read().decode('utf-8')
    df = pd.read_csv(StringIO(csv_string), sep = ",")
    #print('dt antes da validação: \n', df)

    # Realiza as validações nos dados do Dataframe.
    # TODO recuperar, no banco, pelo nome do CSV, o nome da área da origem dos dados    
    df = validarDataframe('rgm', df)
    # Aplica as mudanças no dataframe
    print('dataframe validado: \n', df)
    exit()

    #Criando lotes para inserção no banco e envio para a fila SQS
    try:
      chunk_size = 10
      for start in range(0, df.shape[0], chunk_size):
          df_subset = df.iloc[start:start + chunk_size]
          #print('df_subset: ', df_subset)
          #store_message(df_subset)
          #send_message_tosqs(df_subset)
    except Exception as error:
      print('Erro criar chunks com o dataframe: ', error)

  except Exception as err:
    print(err)
      
  # TODO implement
  return {
    'statusCode': 200,
    'body': json.dumps('Hello from Lambda!')
  }
