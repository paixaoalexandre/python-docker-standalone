#!/bin/bash

# update zip with code
zip -r function.zip lambda_function.py rds_connect_decorator.py util_validacoes.py .env .env.local

# Update lambda code

aws --endpoint-url=http://localhost:4566 \
    lambda update-function-code \
    --function-name  etl1 \
    --zip-file fileb://function.zip

# wait for lambda is active
aws --endpoint-url=http://localhost:4566 lambda wait function-active-v2 --function-name etl1    