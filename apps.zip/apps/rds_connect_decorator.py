import logging
import psycopg2
import json
import os
from dotenv import load_dotenv
import botocore 
import botocore.session 
from aws_secretsmanager_caching import SecretCache, SecretCacheConfig 

# load env variables
if os.path.isfile('.env.local'):
  load_dotenv('.env.local')
else:
  load_dotenv('.env')

logger = logging.getLogger(__name__)
endpoint_url = "http://localhost.localstack.cloud:4566"

if os.getenv('PYTHON_ENV') == 'dev':
  secrets_client = botocore.session.get_session().create_client('secretsmanager', endpoint_url=endpoint_url)
else:  
  secrets_client = botocore.session.get_session().create_client('secretsmanager')


# Decorator
def db_executor(func):
  def with_connection_(*args, **kwargs):
    cache_config = SecretCacheConfig()
    cache = SecretCache( config = cache_config, client = secrets_client)

    secret = cache.get_secret_string('api-pricing-sellin-rds-credentials')  
    #print('secret: ', secret)
    jsonObjSecret = json.loads(secret)
    #print('rds_host: \n', jsonObjSecret[0]['rds_host'])

    try:
      cnn = psycopg2.connect(database = jsonObjSecret[0]['rds_database'], 
                            user = jsonObjSecret[0]['rds_username'], 
                            host= jsonObjSecret[0]['rds_host'],
                            password = jsonObjSecret[0]['rds_pwd'],
                            port = 5432)
        
      rv = func(cnn, *args, **kwargs)
    except Exception:
        logging.error("Database connection error")
        raise
    finally:
        cnn.close()
    return rv
  return with_connection_

@db_executor
def getRegras(cnn, *args, **kwargs):
  cur = cnn.cursor()
  query = """
  SELECT 
    * 
  FROM 
    regra_origem_dado 
  WHERE
    area = %s
  """  
  
  try: 
    cur.execute(query, (args[0],))
  except psycopg2.ProgrammingError as exc:
    print(exc.message)
  except psycopg2.InterfaceError as exc:
    print(exc.message)
  
  rows = cur.fetchall()
  cnn.commit()
  cnn.close()
  return rows
