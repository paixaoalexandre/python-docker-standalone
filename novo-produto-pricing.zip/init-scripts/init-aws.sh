#!/bin/bash

# check if the packages has been installed and file has been zipped
FILE=/src/apps/function.zip
if [ ! -f "$FILE" ]; then

  # AWS configure credentials
  aws configure set aws_access_key_id test \
  && aws configure set aws_secret_access_key test \
  && aws configure set default.region us-east-1

  # install dependencies and create aws layer
  cd /src/layer

  mkdir -p package

  # zip package path
  cd package
  pip3 install --platform manylinux2014_x86_64 --target . --python-version 3.10 --only-binary=:all: pandas
  pip3 install --platform manylinux2014_x86_64 --target . --python-version 3.10 --only-binary=:all: python-dotenv
  pip3 install --platform manylinux2014_x86_64 --target . --python-version 3.10 --only-binary=:all: aws_secretsmanager_caching
  pip3 install --platform manylinux2014_x86_64 --target . --python-version 3.10 --only-binary=:all: psycopg2-binary
  zip -r ../../apps/function.zip .
fi

# Create AWS Lambda
cd /src/apps 

#zip other contents
#cd ..
#zip function.zip lambda_function.py
zip -r function.zip lambda_function.py rds_connect_decorator.py util_validacoes.py .env .env.local

# Create log group
aws --endpoint-url=http://localhost:4566 logs create-log-group --log-group-name /aws/lambda/etl1

# Create lambda 
aws --endpoint-url=http://localhost:4566 \
lambda create-function --function-name etl1 \
--zip-file fileb://function.zip \
--handler lambda_function.lambda_handler --runtime python3.10 \
--role arn:aws:iam::000000000000:role/lambda-role \
--region us-east-1

# Create S3 bucket
aws --endpoint-url=http://localhost:4566 s3 mb s3://etl-files

# wait for lambda is active
aws --endpoint-url=http://localhost:4566 lambda wait function-active-v2 --function-name etl1

# Atach lambda trigger  
aws --endpoint-url=http://localhost:4566 \
s3api put-bucket-notification-configuration --bucket etl-files \
--notification-configuration file://s3-notif-config.json

# Create a dynamodb table
aws --endpoint-url=http://localhost:4566 \
  dynamodb create-table \
  --table-name pricing \
  --attribute-definitions AttributeName=id,AttributeType=S AttributeName=row,AttributeType=S \
  --key-schema AttributeName=id,KeyType=HASH AttributeName=row,KeyType=RANGE \
  --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
  --tags Key=Owner,Value=blueTeam

# Create a sqs queue
aws --endpoint-url=http://localhost:4566 \
  sqs create-queue --queue-name pricing --attributes file://create-queue.json

# Create aws secrets
aws --endpoint-url=http://localhost:4566 --region=us-east-1 secretsmanager create-secret --name api-pricing-sellin-rds-credentials --secret-string '[{"rds_host":"dbpostgres","rds_database":"db_api_pricing_sellin","rds_username":"postgresuser","rds_pwd":"Qm4VQIg_vgGj#9"}]'